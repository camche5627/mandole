// Variables locales
const listaPokemon = document.querySelector("#listaPokemon");
const botonesHeader = document.querySelectorAll(".btn-header");
const inputBusqueda = document.querySelector("#buscador");

// Variables globales
const URL = "https://pokeapi.co/api/v2/pokemon/";
const TOTAL_POKEMON = 151;

let pokemones = [];
let solicitudesCompletadas = 0;

function mostrarPokemon(lista) {
  listaPokemon.innerHTML = "";

  lista.forEach((poke) => {
    const tipos = poke.types.map((t) => t.type.name);
    const tipoPrincipal = tipos[0]; // Para fondo si se usa

    const div = document.createElement("div");
    div.classList.add("pokemon");
    div.innerHTML = `
      <p class="pokemon-id-back">#${poke.id.toString().padStart(3, "0")}</p>
      <div class="pokemon-imagen">
        <img src="${poke.sprites.other["official-artwork"].front_default}" alt="${poke.name}" />
      </div>
      <div class="pokemon-info">
        <div class="nombre-contenedor">
          <p class="pokemon-id">#${poke.id.toString().padStart(3, "0")}</p>
          <h2 class="pokemon-nombre">${poke.name}</h2>
        </div>
        <div class="pokemon-tipos">
          ${tipos.map((tipo) => `<p class="${tipo} tipo">${tipo.toUpperCase()}</p>`).join("")}
        </div>
        <div class="pokemon-stats">
          <p class="stat">${poke.height}m</p>
          <p class="stat">${poke.weight}kg</p>
        </div>
      </div>
    `;
    listaPokemon.append(div);
  });
}

for (let i = 1; i <= TOTAL_POKEMON; i++) {
  fetch(URL + i)
    .then((response) => response.json())
    .then((data) => {
      pokemones.push(data);
      solicitudesCompletadas++;

      if (solicitudesCompletadas === TOTAL_POKEMON) {
        pokemones.sort((a, b) => a.id - b.id);
        mostrarPokemon(pokemones);
      }
    });
}

// Búsqueda por nombre o ID
inputBusqueda.addEventListener("input", () => {
  const valor = inputBusqueda.value.toLowerCase();

  const resultado = pokemones.filter(
    (poke) =>
      poke.name.toLowerCase().includes(valor) || poke.id.toString().includes(valor)
  );

  mostrarPokemon(resultado);
});

// Filtrado
botonesHeader.forEach((boton) =>
  boton.addEventListener("click", (e) => {
    const tipo = e.currentTarget.id;

    if (tipo === "ver-todos") {
      mostrarPokemon(pokemones);
    } else {
      const filtrados = pokemones.filter((poke) =>
        poke.types.some((t) => t.type.name === tipo)
      );
      mostrarPokemon(filtrados);
    }
  })
);